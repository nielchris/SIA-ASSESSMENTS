-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: memeverse
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nickname` varchar(100) DEFAULT NULL,
  `bio` text,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Haizaki','Darkdriven09@gmail.com','$2y$10$C80CtCaZhBG8ZPPi/dm6fuvndJZiljkbQJy4hM5dYwwZWklOL.eh2','loki','loves to read','assets/uploads/avatars/avatar_1_1778555752.jpg','2026-05-03 01:57:08'),(2,'Kratos','lahalaha@gmail.com','$2y$10$J6LRGWdgKE2ROKOWO46eT.MwNsVAY1gQjWL.0Uj/APCpPF3cItFjy','','','assets/uploads/avatars/avatar_2_1778547018.jpg','2026-05-03 02:32:29'),(3,'Anya','FamilySpy1@gmail.com','$2y$10$RzO74gTcIbOWNn.VRt9TQeoBntQ/5iIeBUcseGbNFKC/fumyfj1q6','ming','I love Cats','assets/uploads/avatars/avatar_3_1777776945.jpg','2026-05-03 02:34:39'),(4,'ura-ura','dynasty71@gmail.com','$2y$10$SwR6aUteSBVrSOIg4GJsxed7tLtIdmtZJyMLjo.bScbSLrWiqHF4K','','','assets/uploads/avatars/avatar_4_1778544374.jpg','2026-05-11 23:57:54'),(5,'Madonna','lovelylovely1@gmail.com','$2y$10$xjMNuPdgsfWxgMxHER9.eOVXF5PhgDuGq613ViZ6j50N06AvzGqcy','','','assets/uploads/avatars/avatar_5_1778549850.jpg','2026-05-12 01:36:15');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-12 18:10:06
