<?php
require_once 'includes/header.php';

$post_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($post_id <= 0) {
    redirect('index.php');
}
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div id="postContainer"></div>
        
        <h4 class="mt-4 mb-3">Comments</h4>
        <div id="commentsContainer"></div>
        
        <?php if (isLoggedIn()): ?>
            <div class="card mt-3">
                <div class="card-body">
                    <h5>Add a Comment</h5>
                    <form id="commentForm">
                        <textarea class="form-control mb-2" id="commentContent" rows="3" placeholder="Write something..." required></textarea>
                        <button type="submit" class="btn btn-primary">Post Comment</button>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info mt-3">
                <a href="login.php">Login</a> to add a comment.
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
const postId = <?php echo $post_id; ?>;

async function loadPost() {
    try {
        const response = await fetch(`<?php echo BASE_URL; ?>/api/post.php?id=${postId}`);
        const data = await response.json();
        
        if (data.success) {
            renderPost(data.post, data.user_vote);
        } else {
            document.getElementById('postContainer').innerHTML = '<div class="alert alert-danger">Post not found</div>';
        }
    } catch (error) {
        console.error('Error loading post:', error);
        document.getElementById('postContainer').innerHTML = '<div class="alert alert-danger">Failed to load post</div>';
    }
}

function renderPost(post, userVote) {
    const container = document.getElementById('postContainer');
    const time = new Date(post.created_at).toLocaleString();
    
    container.innerHTML = `
        <div class="card mb-4">
            <div class="card-header d-flex align-items-center">
                <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px;">
                    ${post.user.profile_pic ? 
                        `<img src="${post.user.profile_pic}" class="rounded-circle" style="width: 100%; height: 100%; object-fit: cover;">` : 
                        '<i class="bi bi-person"></i>'
                    }
                </div>
                <div>
                    <a href="<?php echo BASE_URL; ?>/profile.php?id=${post.user.id}" class="text-decoration-none fw-bold">@${post.user.username}</a>
                    <div class="small text-muted">${time}</div>
                    <span class="badge bg-secondary">${post.category.name}</span>
                </div>
            </div>
            <div class="card-body p-0">
                <img src="${post.image_path}" class="img-fluid w-100" alt="${post.title || 'Meme'}" style="max-height: 600px; object-fit: contain; background: #0a0a0a;">
            </div>
            <div class="card-footer">
                ${post.title ? `<h5>${escapeHtml(post.title)}</h5>` : ''}
                ${post.description ? `<p class="card-text">${escapeHtml(post.description)}</p>` : ''}
                <div class="d-flex gap-3">
                    <button class="btn btn-sm ${userVote === 1 ? 'btn-success' : 'btn-outline-success'} vote-btn" data-vote="1">
                        <i class="bi bi-arrow-up"></i> <span id="upvoteCount">${post.upvotes}</span>
                    </button>
                    <button class="btn btn-sm ${userVote === -1 ? 'btn-danger' : 'btn-outline-danger'} vote-btn" data-vote="-1">
                        <i class="bi bi-arrow-down"></i> <span id="downvoteCount">${post.downvotes}</span>
                    </button>
                    <button class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-chat"></i> <span id="commentCountSpan">${post.comment_count}</span>
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.querySelectorAll('.vote-btn').forEach(btn => {
        btn.addEventListener('click', () => handleVote(parseInt(btn.dataset.vote)));
    });
}

async function handleVote(voteValue) {
    <?php if (!isLoggedIn()): ?>
        window.location.href = '<?php echo BASE_URL; ?>/login.php';
        return;
    <?php endif; ?>
    
    try {
        const response = await fetch('<?php echo BASE_URL; ?>/api/vote.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ post_id: postId, vote: voteValue })
        });
        const result = await response.json();
        
        if (result.success) {
            document.getElementById('upvoteCount').textContent = result.upvotes;
            document.getElementById('downvoteCount').textContent = result.downvotes;
            
            document.querySelectorAll('.vote-btn').forEach(btn => {
                const btnVote = parseInt(btn.dataset.vote);
                if (btnVote === 1) {
                    if (result.user_vote === 1) {
                        btn.classList.remove('btn-outline-success');
                        btn.classList.add('btn-success');
                    } else {
                        btn.classList.remove('btn-success');
                        btn.classList.add('btn-outline-success');
                    }
                } else if (btnVote === -1) {
                    if (result.user_vote === -1) {
                        btn.classList.remove('btn-outline-danger');
                        btn.classList.add('btn-danger');
                    } else {
                        btn.classList.remove('btn-danger');
                        btn.classList.add('btn-outline-danger');
                    }
                }
            });
        }
    } catch (error) {
        console.error('Vote error:', error);
    }
}

async function loadComments() {
    try {
        const response = await fetch(`<?php echo BASE_URL; ?>/api/comments.php?post_id=${postId}`);
        const data = await response.json();
        
        const container = document.getElementById('commentsContainer');
        
        if (data.comments.length === 0) {
            container.innerHTML = '<p class="text-muted">No comments yet. Be the first to comment!</p>';
        } else {
            let html = '';
            data.comments.forEach(comment => {
                const time = new Date(comment.created_at).toLocaleString();
                html += `
                    <div class="card mb-2">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <strong><a href="<?php echo BASE_URL; ?>/profile.php?id=${comment.user.id}" class="text-decoration-none">@${comment.user.username}</a></strong>
                                    <small class="text-muted ms-2">${time}</small>
                                </div>
                            </div>
                            <p class="mb-0 mt-2" style="color: #ffffff;">${escapeHtml(comment.content)}</p>
                        </div>
                    </div>
                `;
            });
            container.innerHTML = html;
        }
        
        const commentCountSpan = document.getElementById('commentCountSpan');
        if (commentCountSpan) {
            commentCountSpan.textContent = data.comments.length;
        }
    } catch (error) {
        console.error('Error loading comments:', error);
        document.getElementById('commentsContainer').innerHTML = '<div class="alert alert-danger">Failed to load comments</div>';
    }
}

document.getElementById('commentForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    const content = document.getElementById('commentContent').value.trim();
    
    if (!content) return;
    
    try {
        const response = await fetch('<?php echo BASE_URL; ?>/api/comments.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ post_id: postId, content: content })
        });
        const result = await response.json();
        
        if (result.success) {
            document.getElementById('commentContent').value = '';
            loadComments();
        } else {
            alert(result.error || 'Failed to post comment');
        }
    } catch (error) {
        console.error('Comment error:', error);
        alert('Failed to post comment');
    }
});

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

loadPost();
loadComments();
</script>

<?php require_once 'includes/footer.php'; ?>