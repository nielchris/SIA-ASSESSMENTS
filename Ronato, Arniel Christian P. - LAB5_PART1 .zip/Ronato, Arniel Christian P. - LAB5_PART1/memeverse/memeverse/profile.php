<?php
require_once 'includes/header.php';

$user_id = isset($_GET['id']) ? (int)$_GET['id'] : (isLoggedIn() ? $_SESSION['user_id'] : 0);

if ($user_id <= 0) {
    redirect('login.php');
}

$stmt = $conn->prepare("SELECT id, username, nickname, bio, profile_pic, created_at FROM users WHERE id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$userResult = $stmt->get_result();

if ($userResult->num_rows === 0) {
    redirect('index.php');
}

$user = $userResult->fetch_assoc();
$stmt->close();

if ($user['profile_pic']) {
    if (strpos($user['profile_pic'], '/') === 0) {
        $user['profile_pic'] = substr($user['profile_pic'], 1);
    }
    $user['profile_pic'] = BASE_URL . '/' . $user['profile_pic'];
}

$isOwnProfile = (isLoggedIn() && $_SESSION['user_id'] == $user_id);
?>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <div class="card mb-4">
            <div class="card-body text-center">
                <div class="mb-3">
                    <?php if ($user['profile_pic']): ?>
                        <img src="<?php echo $user['profile_pic']; ?>" class="rounded-circle" style="width: 150px; height: 150px; object-fit: cover;">
                    <?php else: ?>
                        <div class="rounded-circle bg-secondary text-white d-inline-flex align-items-center justify-content-center" style="width: 150px; height: 150px; font-size: 3rem;">
                            <i class="bi bi-person"></i>
                        </div>
                    <?php endif; ?>
                </div>
                
                <h3><?php echo htmlspecialchars($user['nickname'] ?: $user['username']); ?></h3>
                <p class="text-muted">@<?php echo htmlspecialchars($user['username']); ?></p>
                
                <?php if ($user['bio']): ?>
                    <p class="mt-3"><?php echo nl2br(htmlspecialchars($user['bio'])); ?></p>
                <?php endif; ?>
                
                <p class="text-muted small">
                    <i class="bi bi-calendar"></i> Joined <?php echo date('F Y', strtotime($user['created_at'])); ?>
                </p>
                
                <?php if ($isOwnProfile): ?>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editProfileModal">
                        <i class="bi bi-pencil"></i> Edit Profile
                    </button>
                <?php endif; ?>
            </div>
        </div>
        
        <h4 class="mb-3">Posts</h4>
        <div id="postsGrid" class="row g-3"></div>
        <div id="loadingSpinner" class="text-center my-5" style="display: none;">
            <div class="spinner-border text-primary" role="status"></div>
        </div>
        <div id="endMessage" class="text-center my-4 text-muted" style="display: none;">
            No more posts
        </div>
    </div>
</div>

<div class="modal fade" id="editProfileModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Profile</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="profileAlert" class="alert d-none"></div>
                <form id="editProfileForm">
                    <div class="mb-3">
                        <label class="form-label">Nickname</label>
                        <input type="text" class="form-control" id="editNickname" name="nickname" placeholder="Your display name" value="<?php echo htmlspecialchars($user['nickname'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Bio</label>
                        <textarea class="form-control" id="editBio" name="bio" rows="3" placeholder="Tell us about yourself..."><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Profile Picture</label>
                        <input type="file" class="form-control" id="avatarFile" accept="image/*">
                        <div class="form-text">Max 2MB, JPG/PNG/GIF</div>
                        <div id="avatarPreview" class="mt-2 text-center" style="display: none;">
                            <img id="avatarPreviewImg" style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover;">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="saveProfileBtn">Save Changes</button>
            </div>
        </div>
    </div>
</div>

<script>
const userId = <?php echo $user_id; ?>;
const isOwnProfile = <?php echo $isOwnProfile ? 'true' : 'false'; ?>;
let currentPage = 1;
let loading = false;
let hasMore = true;

async function loadUserPosts() {
    if (loading || !hasMore) return;
    
    loading = true;
    document.getElementById('loadingSpinner').style.display = 'block';
    
    try {
        const response = await fetch(`<?php echo BASE_URL; ?>/api/posts.php?page=${currentPage}&limit=12&user_id=${userId}`);
        const data = await response.json();
        
        if (data.success && data.posts.length > 0) {
            renderPosts(data.posts);
            currentPage++;
            hasMore = data.pagination.has_more;
        } else {
            hasMore = false;
            if (currentPage === 1) {
                document.getElementById('postsGrid').innerHTML = '<div class="col-12"><div class="alert alert-info text-center">No posts yet.</div></div>';
            }
        }
        
        if (!hasMore && currentPage > 1) {
            document.getElementById('endMessage').style.display = 'block';
        }
    } catch (error) {
        console.error('Error loading posts:', error);
    } finally {
        loading = false;
        document.getElementById('loadingSpinner').style.display = 'none';
    }
}

function renderPosts(posts) {
    const grid = document.getElementById('postsGrid');
    
    posts.forEach(post => {
        const col = document.createElement('div');
        col.className = 'col-md-4';
        col.innerHTML = `
            <a href="<?php echo BASE_URL; ?>/post.php?id=${post.id}" class="text-decoration-none">
                <div class="card mb-3">
                    <img src="${post.image_path}" class="card-img-top" alt="${post.title || 'Meme'}" style="height: 200px; object-fit: cover;">
                    <div class="card-body p-2 text-center">
                        <small class="text-muted">
                            <i class="bi bi-hand-thumbs-up"></i> ${post.upvotes} 
                            <i class="bi bi-chat ms-2"></i> ${post.comment_count}
                        </small>
                    </div>
                </div>
            </a>
        `;
        grid.appendChild(col);
    });
}

if (isOwnProfile) {
    document.getElementById('avatarFile').addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(ev) {
                document.getElementById('avatarPreviewImg').src = ev.target.result;
                document.getElementById('avatarPreview').style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else {
            document.getElementById('avatarPreview').style.display = 'none';
        }
    });
    
    document.getElementById('saveProfileBtn').addEventListener('click', async function() {
        const nickname = document.getElementById('editNickname').value;
        const bio = document.getElementById('editBio').value;
        const avatarFile = document.getElementById('avatarFile').files[0];
        const alertDiv = document.getElementById('profileAlert');
        
        alertDiv.classList.add('d-none');
        
        try {
            const profileResponse = await fetch('<?php echo BASE_URL; ?>/api/profile.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nickname: nickname, bio: bio })
            });
            const profileResult = await profileResponse.json();
            
            if (!profileResult.success) {
                alertDiv.classList.remove('d-none', 'alert-success');
                alertDiv.classList.add('alert-danger');
                alertDiv.textContent = profileResult.error || 'Failed to update profile';
                alertDiv.classList.remove('d-none');
                return;
            }
            
            if (avatarFile) {
                const formData = new FormData();
                formData.append('avatar', avatarFile);
                
                const avatarResponse = await fetch('<?php echo BASE_URL; ?>/api/upload_avatar.php', {
                    method: 'POST',
                    body: formData
                });
                const avatarResult = await avatarResponse.json();
                
                if (!avatarResult.success) {
                    alert(avatarResult.error || 'Avatar upload failed');
                }
            }
            
            alertDiv.classList.remove('d-none', 'alert-danger');
            alertDiv.classList.add('alert-success');
            alertDiv.textContent = 'Profile updated! Reloading...';
            alertDiv.classList.remove('d-none');
            
            setTimeout(() => window.location.reload(), 1500);
        } catch (error) {
            console.error('Error:', error);
            alertDiv.classList.remove('d-none', 'alert-success');
            alertDiv.classList.add('alert-danger');
            alertDiv.textContent = 'Network error';
            alertDiv.classList.remove('d-none');
        }
    });
}

window.addEventListener('scroll', () => {
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 500) {
        loadUserPosts();
    }
});

loadUserPosts();
</script>

<?php require_once 'includes/footer.php'; ?>