<?php
require_once 'includes/header.php';

$slug = isset($_GET['slug']) ? sanitize($_GET['slug']) : '';

if (empty($slug)) {
    redirect('index.php');
}

// Get category info
$stmt = $conn->prepare("SELECT id, name FROM categories WHERE slug = ?");
$stmt->bind_param('s', $slug);
$stmt->execute();
$catResult = $stmt->get_result();

if ($catResult->num_rows === 0) {
    redirect('index.php');
}

$category = $catResult->fetch_assoc();
$categoryId = $category['id'];
$categoryName = $category['name'];
$stmt->close();
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <h2 class="mb-4">Category: <?php echo htmlspecialchars($categoryName); ?></h2>
        <div id="postsList"></div>
        <div id="loadingSpinner" class="text-center my-5" style="display: none;">
            <div class="spinner-border text-primary" role="status"></div>
        </div>
        <div id="endMessage" class="text-center my-4 text-muted" style="display: none;">
            No more memes in this category
        </div>
    </div>
</div>

<script>
const categoryId = <?php echo $categoryId; ?>;
let currentPage = 1;
let loading = false;
let hasMore = true;
const postsList = document.getElementById('postsList');
const spinner = document.getElementById('loadingSpinner');
const endMessage = document.getElementById('endMessage');

async function loadPosts() {
    if (loading || !hasMore) return;
    
    loading = true;
    spinner.style.display = 'block';
    
    try {
        const response = await fetch(`<?php echo BASE_URL; ?>/api/posts.php?page=${currentPage}&limit=10&category_id=${categoryId}`);
        const data = await response.json();
        
        if (data.success && data.posts.length > 0) {
            renderPosts(data.posts);
            currentPage++;
            hasMore = data.pagination.has_more;
        } else {
            hasMore = false;
            if (currentPage === 1) {
                postsList.innerHTML = '<div class="alert alert-info text-center">No memes in this category yet.</div>';
            }
        }
        
        if (!hasMore && currentPage > 1) {
            endMessage.style.display = 'block';
        }
    } catch (error) {
        console.error('Error loading posts:', error);
        postsList.innerHTML = '<div class="alert alert-danger">Failed to load posts.</div>';
    } finally {
        loading = false;
        spinner.style.display = 'none';
    }
}

function renderPosts(posts) {
    posts.forEach(post => {
        const postCard = document.createElement('div');
        postCard.className = 'card mb-4';
        
        const time = new Date(post.created_at).toLocaleString();
        
        postCard.innerHTML = `
            <div class="card-header d-flex align-items-center">
                <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px;">
                    ${post.user.profile_pic ? 
                        `<img src="${post.user.profile_pic}" class="rounded-circle" style="width: 100%; height: 100%; object-fit: cover;">` : 
                        '<i class="bi bi-person"></i>'
                    }
                </div>
                <div>
                    <a href="<?php echo BASE_URL; ?>/profile.php?id=${post.user.id}" class="text-decoration-none fw-bold">@${post.user.username}</a>
                    <div class="small text-muted">${time}</div>
                    <span class="badge bg-secondary">${post.category.name}</span>
                </div>
            </div>
            <div class="card-body p-0">
                <img src="${post.image_path}" class="img-fluid w-100" alt="${post.title || 'Meme'}" style="max-height: 500px; object-fit: contain; background: #0a0a0a;">
            </div>
            <div class="card-footer">
                ${post.description ? `<p class="card-text mb-2">${escapeHtml(post.description)}</p>` : ''}
                <div class="d-flex gap-3">
                    <button class="btn btn-sm btn-outline-success vote-btn" data-post-id="${post.id}" data-vote="1">
                        <i class="bi bi-arrow-up"></i> <span class="up-${post.id}">${post.upvotes}</span>
                    </button>
                    <button class="btn btn-sm btn-outline-danger vote-btn" data-post-id="${post.id}" data-vote="-1">
                        <i class="bi bi-arrow-down"></i> <span class="down-${post.id}">${post.downvotes}</span>
                    </button>
                    <a href="<?php echo BASE_URL; ?>/post.php?id=${post.id}" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-chat"></i> ${post.comment_count}
                    </a>
                </div>
            </div>
        `;
        
        postsList.appendChild(postCard);
    });
    
    document.querySelectorAll('.vote-btn').forEach(btn => {
        btn.removeEventListener('click', voteHandler);
        btn.addEventListener('click', voteHandler);
    });
}

async function voteHandler(e) {
    const btn = e.currentTarget;
    const postId = btn.dataset.postId;
    const vote = parseInt(btn.dataset.vote);
    
    <?php if (!isLoggedIn()): ?>
        window.location.href = '<?php echo BASE_URL; ?>/login.php';
        return;
    <?php endif; ?>
    
    try {
        const response = await fetch('<?php echo BASE_URL; ?>/api/vote.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ post_id: postId, vote: vote })
        });
        const result = await response.json();
        
        if (result.success) {
            const upSpan = document.querySelector(`.up-${postId}`);
            const downSpan = document.querySelector(`.down-${postId}`);
            if (upSpan) upSpan.textContent = result.upvotes;
            if (downSpan) downSpan.textContent = result.downvotes;
        }
    } catch (error) {
        console.error('Vote error:', error);
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

window.addEventListener('scroll', () => {
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 500) {
        loadPosts();
    }
});

loadPosts();
</script>

<?php require_once 'includes/footer.php'; ?>