<?php
require_once dirname(__DIR__) . '/includes/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';

if (!isLoggedIn()) {
    jsonResponse(['error' => 'Authentication required'], 401);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    jsonResponse(['error' => 'Invalid JSON'], 400);
}

$post_id = isset($input['post_id']) ? (int)$input['post_id'] : 0;
$vote = isset($input['vote']) ? (int)$input['vote'] : 0;

if ($post_id <= 0 || !in_array($vote, [-1, 0, 1])) {
    jsonResponse(['error' => 'Invalid vote data'], 400);
}

$user_id = $_SESSION['user_id'];

// Check if post exists
$checkStmt = $conn->prepare("SELECT id FROM posts WHERE id = ?");
$checkStmt->bind_param('i', $post_id);
$checkStmt->execute();
$checkStmt->store_result();
if ($checkStmt->num_rows === 0) {
    jsonResponse(['error' => 'Post not found'], 404);
}
$checkStmt->close();

// Check if user already voted
$checkVoteStmt = $conn->prepare("SELECT id, vote FROM votes WHERE user_id = ? AND post_id = ?");
$checkVoteStmt->bind_param('ii', $user_id, $post_id);
$checkVoteStmt->execute();
$checkVoteResult = $checkVoteStmt->get_result();
$existingVote = null;
if ($row = $checkVoteResult->fetch_assoc()) {
    $existingVote = $row;
}
$checkVoteStmt->close();

if ($existingVote) {
    // User already voted - UPDATE their vote (change from upvote to downvote or vice versa)
    $stmt = $conn->prepare("UPDATE votes SET vote = ? WHERE user_id = ? AND post_id = ?");
    $stmt->bind_param('iii', $vote, $user_id, $post_id);
    $stmt->execute();
    $stmt->close();
} else {
    // User has not voted - INSERT new vote
    $stmt = $conn->prepare("INSERT INTO votes (user_id, post_id, vote) VALUES (?, ?, ?)");
    $stmt->bind_param('iii', $user_id, $post_id, $vote);
    $stmt->execute();
    $stmt->close();
}

// Get updated counts
$countStmt = $conn->prepare("
    SELECT 
        COALESCE(SUM(CASE WHEN vote = 1 THEN 1 ELSE 0 END), 0) as upvotes,
        COALESCE(SUM(CASE WHEN vote = -1 THEN 1 ELSE 0 END), 0) as downvotes
    FROM votes 
    WHERE post_id = ?
");
$countStmt->bind_param('i', $post_id);
$countStmt->execute();
$countResult = $countStmt->get_result();
$counts = $countResult->fetch_assoc();

// Get user's current vote
$userVoteStmt = $conn->prepare("SELECT vote FROM votes WHERE user_id = ? AND post_id = ?");
$userVoteStmt->bind_param('ii', $user_id, $post_id);
$userVoteStmt->execute();
$userVoteResult = $userVoteStmt->get_result();
$userVote = 0;
if ($userVoteRow = $userVoteResult->fetch_assoc()) {
    $userVote = (int)$userVoteRow['vote'];
}
$userVoteStmt->close();

jsonResponse([
    'success' => true,
    'upvotes' => (int)$counts['upvotes'],
    'downvotes' => (int)$counts['downvotes'],
    'user_vote' => $userVote
]);
?>