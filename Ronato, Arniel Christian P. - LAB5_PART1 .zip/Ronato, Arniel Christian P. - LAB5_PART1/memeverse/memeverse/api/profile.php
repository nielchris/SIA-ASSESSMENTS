<?php
require_once dirname(__DIR__) . '/includes/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // Get user profile
    $user_id = isset($_GET['id']) ? (int)$_GET['id'] : (isLoggedIn() ? $_SESSION['user_id'] : 0);
    
    if ($user_id <= 0) {
        jsonResponse(['error' => 'Invalid user'], 400);
    }
    
    $stmt = $conn->prepare("SELECT id, username, nickname, bio, profile_pic, created_at FROM users WHERE id = ?");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        jsonResponse(['error' => 'User not found'], 404);
    }
    
    $user = $result->fetch_assoc();
    
    // Fix profile pic path
    if ($user['profile_pic']) {
        if (strpos($user['profile_pic'], '/') === 0) {
            $user['profile_pic'] = substr($user['profile_pic'], 1);
        }
        $user['profile_pic'] = BASE_URL . '/' . $user['profile_pic'];
    }
    
    // Get post count
    $postStmt = $conn->prepare("SELECT COUNT(*) as post_count FROM posts WHERE user_id = ?");
    $postStmt->bind_param('i', $user_id);
    $postStmt->execute();
    $postResult = $postStmt->get_result();
    $postCount = $postResult->fetch_assoc()['post_count'];
    
    jsonResponse([
        'success' => true,
        'user' => $user,
        'post_count' => (int)$postCount
    ]);
    
} elseif ($method === 'POST') {
    // Update user profile (requires login)
    if (!isLoggedIn()) {
        jsonResponse(['error' => 'Authentication required'], 401);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        jsonResponse(['error' => 'Invalid JSON'], 400);
    }
    
    $nickname = isset($input['nickname']) ? trim($input['nickname']) : null;
    $bio = isset($input['bio']) ? trim($input['bio']) : null;
    $user_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("UPDATE users SET nickname = ?, bio = ? WHERE id = ?");
    $stmt->bind_param('ssi', $nickname, $bio, $user_id);
    
    if ($stmt->execute()) {
        jsonResponse([
            'success' => true,
            'message' => 'Profile updated successfully'
        ]);
    } else {
        jsonResponse(['error' => 'Failed to update profile'], 500);
    }
} else {
    jsonResponse(['error' => 'Method not allowed'], 405);
}
?>