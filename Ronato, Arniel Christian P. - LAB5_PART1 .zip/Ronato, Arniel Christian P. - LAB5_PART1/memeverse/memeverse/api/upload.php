<?php
require_once dirname(__DIR__) . '/includes/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';

if (!isLoggedIn()) {
    jsonResponse(['error' => 'Authentication required'], 401);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

$category_id = isset($_POST['category_id']) ? (int)$_POST['category_id'] : 0;
$title = isset($_POST['title']) ? trim($_POST['title']) : '';
$description = isset($_POST['description']) ? trim($_POST['description']) : '';

if ($category_id <= 0) {
    jsonResponse(['error' => 'Please select a category'], 400);
}

// Verify category exists
$stmt = $conn->prepare("SELECT id FROM categories WHERE id = ?");
$stmt->bind_param('i', $category_id);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows === 0) {
    jsonResponse(['error' => 'Invalid category'], 400);
}
$stmt->close();

// Check file upload
if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    $errorCode = $_FILES['image']['error'] ?? UPLOAD_ERR_NO_FILE;
    $messages = [
        UPLOAD_ERR_INI_SIZE => 'File too large (server limit)',
        UPLOAD_ERR_FORM_SIZE => 'File too large (form limit)',
        UPLOAD_ERR_PARTIAL => 'File only partially uploaded',
        UPLOAD_ERR_NO_FILE => 'No file uploaded',
        UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
        UPLOAD_ERR_CANT_WRITE => 'Failed to write file',
        UPLOAD_ERR_EXTENSION => 'Upload stopped by extension'
    ];
    $msg = $messages[$errorCode] ?? 'Unknown upload error';
    jsonResponse(['error' => $msg], 400);
}

$file = $_FILES['image'];

// Check file size (5MB max)
if ($file['size'] > 5 * 1024 * 1024) {
    jsonResponse(['error' => 'File must be less than 5MB'], 400);
}

// Check file type
$allowedMimes = ['image/jpeg', 'image/png', 'image/gif'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if (!in_array($mime, $allowedMimes)) {
    jsonResponse(['error' => 'Only JPG, PNG, and GIF images are allowed'], 400);
}

// Create upload directory if it doesn't exist
$uploadDir = dirname(__DIR__) . '/assets/uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Generate unique filename
$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = uniqid() . '_' . time() . '.' . $ext;
$destination = $uploadDir . $filename;

if (!move_uploaded_file($file['tmp_name'], $destination)) {
    jsonResponse(['error' => 'Failed to save uploaded file'], 500);
}

$user_id = $_SESSION['user_id'];
$image_path = 'assets/uploads/' . $filename;

// Insert into database
$stmt = $conn->prepare("INSERT INTO posts (user_id, category_id, title, description, image_path) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param('iisss', $user_id, $category_id, $title, $description, $image_path);

if ($stmt->execute()) {
    $post_id = $stmt->insert_id;
    jsonResponse([
        'success' => true,
        'message' => 'Post uploaded successfully',
        'post_id' => $post_id
    ], 201);
} else {
    // Delete the uploaded file if database insert fails
    unlink($destination);
    jsonResponse(['error' => 'Database error: ' . $stmt->error], 500);
}
?>