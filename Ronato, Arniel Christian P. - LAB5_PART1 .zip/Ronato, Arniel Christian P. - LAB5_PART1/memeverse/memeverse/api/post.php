<?php
require_once dirname(__DIR__) . '/includes/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';

$post_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($post_id <= 0) {
    jsonResponse(['error' => 'Invalid post ID'], 400);
}

$sql = "SELECT 
            p.*, 
            u.username, 
            u.profile_pic,
            c.name as category_name,
            c.slug as category_slug,
            COALESCE(up.upvotes, 0) as upvotes,
            COALESCE(down.downvotes, 0) as downvotes,
            COALESCE(comm.comment_count, 0) as comment_count
        FROM posts p
        JOIN users u ON p.user_id = u.id
        JOIN categories c ON p.category_id = c.id
        LEFT JOIN (
            SELECT post_id, COUNT(*) as upvotes 
            FROM votes 
            WHERE vote = 1 
            GROUP BY post_id
        ) up ON p.id = up.post_id
        LEFT JOIN (
            SELECT post_id, COUNT(*) as downvotes 
            FROM votes 
            WHERE vote = -1 
            GROUP BY post_id
        ) down ON p.id = down.post_id
        LEFT JOIN (
            SELECT post_id, COUNT(*) as comment_count 
            FROM comments 
            GROUP BY post_id
        ) comm ON p.id = comm.post_id
        WHERE p.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $post_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    jsonResponse(['error' => 'Post not found'], 404);
}

$row = $result->fetch_assoc();

// Fix image path
$imagePath = $row['image_path'];
if (strpos($imagePath, '/') === 0) {
    $imagePath = substr($imagePath, 1);
}
$fullImageUrl = BASE_URL . '/' . $imagePath;

// Fix avatar path
$avatarUrl = null;
if ($row['profile_pic']) {
    if (strpos($row['profile_pic'], '/') === 0) {
        $row['profile_pic'] = substr($row['profile_pic'], 1);
    }
    $avatarUrl = BASE_URL . '/' . $row['profile_pic'];
}

// Get user's vote on this post
$user_vote = 0;
if (isLoggedIn()) {
    $voteStmt = $conn->prepare("SELECT vote FROM votes WHERE user_id = ? AND post_id = ?");
    $voteStmt->bind_param('ii', $_SESSION['user_id'], $post_id);
    $voteStmt->execute();
    $voteResult = $voteStmt->get_result();
    if ($voteRow = $voteResult->fetch_assoc()) {
        $user_vote = (int)$voteRow['vote'];
    }
}

$post = [
    'id' => $row['id'],
    'title' => $row['title'],
    'description' => $row['description'],
    'image_path' => $fullImageUrl,
    'created_at' => $row['created_at'],
    'upvotes' => (int)$row['upvotes'],
    'downvotes' => (int)$row['downvotes'],
    'comment_count' => (int)$row['comment_count'],
    'category' => [
        'name' => $row['category_name'],
        'slug' => $row['category_slug']
    ],
    'user' => [
        'id' => $row['user_id'],
        'username' => $row['username'],
        'profile_pic' => $avatarUrl
    ]
];

jsonResponse([
    'success' => true,
    'post' => $post,
    'user_vote' => $user_vote
]);
?>