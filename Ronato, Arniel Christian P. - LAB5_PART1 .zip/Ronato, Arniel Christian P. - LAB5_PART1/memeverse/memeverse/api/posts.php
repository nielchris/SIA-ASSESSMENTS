<?php
require_once dirname(__DIR__) . '/includes/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';

header('Content-Type: application/json');

$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = isset($_GET['limit']) ? min(50, max(1, (int)$_GET['limit'])) : 10;
$offset = ($page - 1) * $limit;

$where = [];
$params = [];
$types = '';

// Category filter
if (isset($_GET['category_id']) && is_numeric($_GET['category_id'])) {
    $where[] = "p.category_id = ?";
    $params[] = (int)$_GET['category_id'];
    $types .= 'i';
}

// User filter (profile page)
if (isset($_GET['user_id']) && is_numeric($_GET['user_id'])) {
    $where[] = "p.user_id = ?";
    $params[] = (int)$_GET['user_id'];
    $types .= 'i';
}

$whereClause = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

// Get total count for pagination
$countSql = "SELECT COUNT(*) as total FROM posts p $whereClause";
$countStmt = $conn->prepare($countSql);
if (!empty($params)) {
    $countStmt->bind_param($types, ...$params);
}
$countStmt->execute();
$totalResult = $countStmt->get_result();
$totalPosts = $totalResult->fetch_assoc()['total'];
$countStmt->close();

// Main query to get posts with vote counts and comment counts
$sql = "SELECT 
            p.*, 
            u.username, 
            u.profile_pic,
            c.name as category_name,
            c.slug as category_slug,
            COALESCE(up.upvotes, 0) as upvotes,
            COALESCE(down.downvotes, 0) as downvotes,
            COALESCE(comm.comment_count, 0) as comment_count
        FROM posts p
        JOIN users u ON p.user_id = u.id
        JOIN categories c ON p.category_id = c.id
        LEFT JOIN (
            SELECT post_id, COUNT(*) as upvotes 
            FROM votes 
            WHERE vote = 1 
            GROUP BY post_id
        ) up ON p.id = up.post_id
        LEFT JOIN (
            SELECT post_id, COUNT(*) as downvotes 
            FROM votes 
            WHERE vote = -1 
            GROUP BY post_id
        ) down ON p.id = down.post_id
        LEFT JOIN (
            SELECT post_id, COUNT(*) as comment_count 
            FROM comments 
            GROUP BY post_id
        ) comm ON p.id = comm.post_id
        $whereClause
        ORDER BY p.created_at DESC
        LIMIT ? OFFSET ?";

$params[] = $limit;
$params[] = $offset;
$types .= 'ii';

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$posts = [];
while ($row = $result->fetch_assoc()) {
    // Fix image path
    $imagePath = $row['image_path'];
    if (strpos($imagePath, '/') === 0) {
        $imagePath = substr($imagePath, 1);
    }
    $fullImageUrl = BASE_URL . '/' . $imagePath;
    
    // Fix avatar path
    $avatarUrl = null;
    if ($row['profile_pic']) {
        if (strpos($row['profile_pic'], '/') === 0) {
            $row['profile_pic'] = substr($row['profile_pic'], 1);
        }
        $avatarUrl = BASE_URL . '/' . $row['profile_pic'];
    }
    
    $posts[] = [
        'id' => $row['id'],
        'title' => $row['title'],
        'description' => $row['description'],
        'image_path' => $fullImageUrl,
        'created_at' => $row['created_at'],
        'upvotes' => (int)$row['upvotes'],
        'downvotes' => (int)$row['downvotes'],
        'comment_count' => (int)$row['comment_count'],
        'category' => [
            'name' => $row['category_name'],
            'slug' => $row['category_slug']
        ],
        'user' => [
            'id' => $row['user_id'],
            'username' => $row['username'],
            'profile_pic' => $avatarUrl
        ]
    ];
}

$hasMore = ($offset + $limit) < $totalPosts;

echo json_encode([
    'success' => true,
    'posts' => $posts,
    'pagination' => [
        'current_page' => $page,
        'per_page' => $limit,
        'total_posts' => $totalPosts,
        'has_more' => $hasMore
    ]
]);
?>