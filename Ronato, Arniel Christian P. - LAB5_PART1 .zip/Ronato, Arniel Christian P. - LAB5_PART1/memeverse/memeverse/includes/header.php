<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Memeverse - Modern Meme Sharing</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #0a0a0a;
            --bg-card: #141414;
            --bg-sidebar: #0f0f0f;
            --border-subtle: #2a2a2a;
            --text-primary: #f0f0f0;
            --text-secondary: #a0a0a0;
            --pastel-purple: #c7b9ff;
            --pastel-mint: #b8e1d2;
            --accent-hover: #c7b9ff20;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-dark);
            color: var(--text-primary);
            line-height: 1.5;
        }

        .navbar {
            background: var(--bg-card);
            border-bottom: 1px solid var(--border-subtle);
            padding: 0.8rem 1rem;
        }
        
        .navbar-brand {
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--pastel-purple) !important;
        }
        
        .navbar-brand span {
            color: var(--pastel-mint);
        }
        
        .navbar-nav .nav-link {
            color: var(--text-primary) !important;
            font-weight: 500;
            transition: color 0.2s;
        }
        
        .navbar-nav .nav-link:hover {
            color: var(--pastel-purple) !important;
        }
        
        .sidebar {
            background: var(--bg-sidebar);
            border-right: 1px solid var(--border-subtle);
            min-height: 100vh;
            position: sticky;
            top: 0;
            overflow-y: auto;
            padding: 2rem 1rem;
        }
        
        .sidebar h5 {
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: var(--text-secondary);
            margin-bottom: 1.5rem;
            font-weight: 500;
        }
        
        .category-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .category-list li {
            margin-bottom: 0.25rem;
        }
        
        .category-link {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.7rem 1rem;
            color: var(--text-primary);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.2s;
            font-weight: 500;
            font-size: 0.9rem;
        }
        
        .category-link i {
            width: 1.5rem;
            font-size: 1.2rem;
            color: var(--pastel-purple);
        }
        
        .category-link:hover {
            background: var(--accent-hover);
            color: var(--pastel-purple);
            transform: translateX(5px);
        }
        
        .category-link.active {
            background: rgba(199, 185, 255, 0.12);
            color: var(--pastel-purple);
            border-left: 3px solid var(--pastel-purple);
            font-weight: 600;
        }
        
        .card {
            background: var(--bg-card);
            border: 1px solid var(--border-subtle);
            border-radius: 24px;
        }
        
        .card-header {
            background: var(--bg-card);
            border-bottom: 1px solid var(--border-subtle);
        }
        
        .card-footer {
            background: var(--bg-card);
            border-top: 1px solid var(--border-subtle);
        }
        
        .text-muted {
            color: var(--text-secondary) !important;
        }
        
        .form-control, .form-select {
            background: #1a1a1a;
            border: 1px solid var(--border-subtle);
            color: var(--text-primary);
            border-radius: 12px;
            padding: 0.7rem 1rem;
        }
        
        .form-control:focus, .form-select:focus {
            background: #1a1a1a;
            border-color: var(--pastel-purple);
            box-shadow: 0 0 0 0.2rem rgba(199, 185, 255, 0.25);
            color: var(--text-primary);
        }
        
        .form-label {
            color: var(--text-primary);
        }
        
        .btn-primary {
            background: var(--pastel-purple);
            border: none;
            color: var(--bg-dark);
            font-weight: 600;
            padding: 0.7rem;
            border-radius: 40px;
        }
        
        .btn-primary:hover {
            background: var(--pastel-purple);
            opacity: 0.9;
            color: var(--bg-dark);
        }
        
        footer {
            background: var(--bg-card);
            border-top: 1px solid var(--border-subtle);
            padding: 2rem 0;
            margin-top: 3rem;
        }
        
        @media (max-width: 991.98px) {
            .sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo BASE_URL; ?>/index.php">Meme<span>Verse</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto gap-2">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>/index.php"><i class="bi bi-house-door"></i> Home</a>
                    </li>
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>/upload.php"><i class="bi bi-plus-circle"></i> Upload</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>/profile.php"><i class="bi bi-person"></i> Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" id="logoutLink"><i class="bi bi-box-arrow-right"></i> Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>/login.php"><i class="bi bi-box-arrow-in-right"></i> Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>/register.php"><i class="bi bi-person-plus"></i> Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-xl-2 sidebar d-none d-lg-block">
                <h5>DISCOVER</h5>
                <ul class="category-list">
                    <li>
                        <a href="<?php echo BASE_URL; ?>/index.php" class="category-link <?php echo (!isset($_GET['slug'])) ? 'active' : ''; ?>">
                            <i class="bi bi-grid-3x3-gap-fill"></i> All Memes
                        </a>
                    </li>
                    <?php 
                    $catQuery = $conn->query("SELECT slug, name FROM categories ORDER BY name");
                    if ($catQuery) {
                        while ($cat = $catQuery->fetch_assoc()) {
                            $active = (isset($_GET['slug']) && $_GET['slug'] === $cat['slug']) ? 'active' : '';
                            $icon = '';
                            switch ($cat['slug']) {
                                case 'funny': $icon = 'bi bi-emoji-laughing'; break;
                                case 'animals': $icon = 'bi bi-egg-fried'; break;
                                case 'music': $icon = 'bi bi-music-note-beamed'; break;
                                case 'tv': $icon = 'bi bi-tv'; break;
                                case 'games': $icon = 'bi bi-controller'; break;
                                case 'movie': $icon = 'bi bi-film'; break;
                                case 'sport': $icon = 'bi bi-trophy'; break;
                                default: $icon = 'bi bi-tag';
                            }
                            echo '<li><a href="' . BASE_URL . '/category.php?slug=' . $cat['slug'] . '" class="category-link ' . $active . '"><i class="' . $icon . '"></i> ' . htmlspecialchars($cat['name']) . '</a></li>';
                        }
                    }
                    ?>
                </ul>
            </div>
            
            <div class="col-lg-9 col-xl-10 main-content px-4 py-4">