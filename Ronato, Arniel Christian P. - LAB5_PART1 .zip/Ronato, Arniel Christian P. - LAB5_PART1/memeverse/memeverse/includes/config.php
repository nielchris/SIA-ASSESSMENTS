<?php
session_start();

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'RALPH-BSIT3A');  // Your password here
define('DB_NAME', 'memeverse');
define('BASE_URL', 'http://localhost/memeverse');  // Full URL for links

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die(json_encode(['error' => 'Database connection failed: ' . $conn->connect_error]));
}
$conn->set_charset('utf8mb4');
?>