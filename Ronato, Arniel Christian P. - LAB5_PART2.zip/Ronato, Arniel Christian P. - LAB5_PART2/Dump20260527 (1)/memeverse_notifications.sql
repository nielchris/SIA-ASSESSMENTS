-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: memeverse
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type` enum('comment','reply','vote','follow','message') NOT NULL,
  `source_id` int NOT NULL,
  `actor_id` int NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `notifications_ibfk_2` (`actor_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,1,'vote',2,2,1,'2026-05-27 01:49:43'),(2,1,'comment',2,2,1,'2026-05-27 01:49:52'),(3,1,'message',1,2,1,'2026-05-27 02:02:43'),(4,2,'message',2,1,1,'2026-05-27 02:09:31'),(5,2,'vote',3,1,1,'2026-05-27 02:10:01'),(6,1,'message',3,2,0,'2026-05-27 02:11:25'),(7,2,'vote',3,4,1,'2026-05-27 07:37:31'),(8,2,'comment',3,4,1,'2026-05-27 07:37:45'),(9,2,'follow',2,4,1,'2026-05-27 07:38:00'),(10,2,'message',4,1,1,'2026-05-27 07:42:29'),(11,4,'vote',4,1,0,'2026-05-27 07:42:36'),(12,4,'comment',4,1,0,'2026-05-27 07:42:55'),(13,4,'vote',4,2,0,'2026-05-27 07:44:07'),(14,4,'comment',4,2,0,'2026-05-27 07:44:18'),(15,4,'follow',4,2,0,'2026-05-27 07:44:35'),(16,4,'vote',4,5,0,'2026-05-27 07:46:53'),(17,4,'comment',4,5,0,'2026-05-27 07:47:09'),(18,4,'vote',4,6,0,'2026-05-27 07:49:43'),(19,2,'vote',3,6,0,'2026-05-27 07:49:50'),(20,2,'comment',3,6,0,'2026-05-27 07:49:56'),(21,4,'comment',4,6,0,'2026-05-27 07:50:19'),(22,5,'message',5,6,0,'2026-05-27 08:04:45'),(23,5,'follow',5,6,0,'2026-05-27 08:04:58');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-27 16:09:10
