-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: memeverse
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nickname` varchar(100) DEFAULT NULL,
  `bio` text,
  `avatar` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_admin` tinyint DEFAULT '0',
  `banned` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Kabuki','Messiah0@gmail.com','$2y$10$GMzJGNHJMhBxLcyqWA9/J.Z0RLZaE8RoT4Bqihz9Akt5TlJX33Z9q','Ultra Messiah','Anoooooo jaaayyy','6a164a55ad357_1779845717.jpg','2026-05-27 01:26:12',0,0),(2,'Ralphyy','mabeyyynii0@gmail.com','$2y$10$VBU2AtOXpvbwIJGcaOlFKOq5TRk8ER6gkGFPN0To5o/0EwNIOE1PC','Larphyy','haloooo','6a164dafe8cd7_1779846575.jpg','2026-05-27 01:48:15',0,0),(3,'klutz','oracle21@gmail.com','$2y$10$LscpvMWjRdH0q.XarabZ/u56DB.2/HN4kp9oDhHy4QzIlGVm70oQa','FinalBoss',NULL,NULL,'2026-05-27 07:29:30',0,0),(4,'Karasu','WickedSick@gmail.com','$2y$10$Q7jhOB9kv6A5TSqoJANSBeUwy5sJ9F5glpHxzNRmahnLLEu3RF3iS','Purple_Guy','i love cats','6a169f2c511df_1779867436.jpg','2026-05-27 07:31:28',0,0),(5,'Hapii','kolakola@gmail.com','$2y$10$/FBhw94WGdC6ceftLMSPsepkgNuzicXDIszynniiodwI4wJLSQBUa','Ayaa','','6a16a19d80f10_1779868061.jpg','2026-05-27 07:45:50',0,0),(6,'Doreamon','walawala@gmail.com','$2y$10$LEuD2yVmFNkQXRlARWWrLOWtPEeTDVExFFbe/yUsPlbMWOHxwpJ3e','doZzzzz','','6a16a56497d57_1779869028.jpg','2026-05-27 07:49:24',0,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-27 16:09:09
